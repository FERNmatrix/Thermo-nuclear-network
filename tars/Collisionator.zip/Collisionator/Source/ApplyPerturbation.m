function[ N_Pert ] = ApplyPerturbation(Nold, amp, dV, N_g, PertCase)
    
 

% --- Returns Nold if the amplitude is set to zero ---
    if ( amp == 0 )
        
        N_Pert = Nold;
    
% --- Perturbs the density using a random number generator. Non-conservative case ---     
        
    else
        
        if ( PertCase == 1 )
        
           N_Pert = (1.0 + amp *2.0*(0.5 - rand(40,1))).*Nold;
           N_Pert = min( 1.0, max( 0.0, N_Pert ) );
   
        else
            
% --- Perturbs and conserves particle number using alpha ---
    
          if ( PertCase == 2 )
        
             N_prime = (1.0 + amp *2.0*(0.5 - rand(40,1))).*Nold;
             N_prime = min( 1.0, max( 0.0, N_prime ) );
         
             alpha   = sum( Nold .* dV )./sum( N_prime .* dV );
             N_Pert  = alpha * N_prime;
             
          else 
              
% --- Uses linear least squares method to conserve particle number --- 
              
              if ( PertCase == 3 )
                  
                 N_Prime = (1.0 + amp *2.0*(0.5 - rand(40,1))).*Nold;                 
                 N_Pert  = lsqlin( eye(N_g), N_Prime, [], [], dV', sum( Nold .* dV ), zeros(N_g,1), ones(N_g,1));
                 
              end
             
          end
          
        end
        
   end
    
        

