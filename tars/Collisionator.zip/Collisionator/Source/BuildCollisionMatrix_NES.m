function [ A, k ] = BuildCollisionMatrix_NES( R_In, R_Out, N, dV, N_g, tol )

  A = zeros( N_g, N_g );
  k = zeros( N_g, 1 );
  for i = 1 : N_g
  for j = 1 : N_g

    if( i ~= j )

      B = ( R_In(i,j) * dV(i) + R_Out(i,j) * dV(j) );
      C = dV(i) * N(i) + dV(j) * N(j);
        
      a = ( R_In(i,j) - R_Out(i,j) ) * dV(i);
      b = B + ( R_In(i,j) - R_Out(i,j) ) * C;
      c = R_In(i,j) * C;
      d = b^(2) - (4.0 * a * c);
        
      N_Eq_i = 0.5 * ( b - sqrt( d ) ) / a;
      N_Eq_j = ( C - N_Eq_i * dV(i) ) / dV(j);

    else

      N_Eq_i = N(i);
      N_Eq_j = N(j);

    end

    % --- Include Reaction Pairs _Not_ in Equilibrium:
    
    diff_i = abs( N_Eq_i - N(i) ) / max( [ 1.d-16 N_Eq_i ] );
    diff_j = abs( N_Eq_j - N(j) ) / max( [ 1.d-16 N_Eq_j ] );
    if( or( diff_i > tol, diff_j > tol ) )

      A(i,j) = A(i,j) + (1.0 - N(i)) * R_In(i,j) * dV(j);
      A(i,i) = A(i,i) - R_Out(i,j) * dV(j) * (1.0 -  N(j));
        
      k(i) = k(i) + R_Out(i,j) * dV(j)...
             + ( (R_In(i,j) * dV(j) - R_Out(i,j) * dV(j)) * N(j) );

    end

  end
  end

end