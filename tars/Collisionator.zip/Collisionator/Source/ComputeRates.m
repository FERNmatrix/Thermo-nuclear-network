function [ F, k ] = ComputeRates( R_In, R_Out, N, dV, N_g, tol )

  F = R_In * ( N .* dV );
  k = F + R_Out * ( ( 1.0 - N ) .* dV );
  
end

