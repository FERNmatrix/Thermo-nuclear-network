function [ tVec, dtVec, dNVec, kVec, cMat, cycleVec, truecycleVec, NMat, eC, Branch, dt_FE, dt_EA, dt_PE ] = GetTrace_Plotfile( FileDir, FileName, Lo, Hi )

  nFiles = Hi - Lo + 1;
  
  tVec  = zeros( nFiles, 1 );
  dtVec = zeros( nFiles, 1 );
  dNVec = zeros( nFiles, 1 );
  kVec  = zeros( nFiles, 40 );
  cMat = zeros(nFiles, 40, 40);
  cycleVec = zeros( nFiles, 1 );
  truecycleVec = zeros( nFiles, 1 );
  NMat   = zeros( nFiles, 40 );
  eC     = zeros( nFiles, 40 );
  Branch = zeros( nFiles, 1) ;
  dt_FE  = zeros( nFiles, 1 );
  dt_EA  = zeros( nFiles, 1 );
  dt_PE  = zeros( nFiles, 1 );
  
  iFile = 0;
  for i = Lo : Hi
      
      
        iFile = iFile + 1;
    
        Data = load( [ FileDir '/' FileName '_' num2str( i, '%08d' ) ] );
    
        if (isfield(Data, 't') == 1)
            tVec(iFile) = Data.t;
        else 
            tVec(iFile) = 0;
        end
        
        if (isfield(Data, 'dt') == 1)
            dtVec(iFile) = Data.dt;
        else
            dtVec(iFile) = 0; 
        end
        
        if (isfield(Data, 'kVec') == 1)
            kVec(iFile,:) = Data.kVec; 
        else
            kVec(iFile,:) = 0;
        end
        
        if (isfield(Data, 'cMat') == 1)
            cMat(iFile,:,:) = Data.cMat;
        else
            cMat(iFile,:,:) = 0;
        end
        
        if (isfield(Data, 'cycle') == 1)
            cycleVec(iFile) = Data.cycle;
        else 
            cycleVec(iFile) = 0;
        end
        
        if (isfield(Data, 'true_cycle') == 1)
            truecycleVec(iFile) = Data.true_cycle; 
        else
            truecycleVec(iFile) = 0;
        end
          
        if (isfield(Data, 'eC') == 1)
            eC(iFile,:) = Data.eC;
        else 
            eC(iFile,:) = 0;
        end
        
        if(isfield(Data, 'Branch') == 1)
            Branch(iFile) = Data.Branch;
        else 
            Branch(iFile) = 0;
            
        end
        
        if (isfield(Data, 'dt_FE') == 1)
            dt_FE(iFile) = Data.dt_FE;
        else 
            dt_FE(iFile) = 0;
        end
        
        if (isfield(Data, 'dt_EA') == 1)
            dt_EA(iFile) = Data.dt_EA;
        else 
            dt_EA(iFile) = 0;
        end
        
        if (isfield(Data, 'dt_PE') == 1)
            dt_PE(iFile) = Data.dt_PE;
        else 
            dt_PE(iFile) = 0;
        end
        
        
        if (isfield(Data, 'N') == 1)
            NMat(iFile,:) = Data.N;
            dNVec(iFile)   = sum( NMat(iFile,:) * Data.dV(:) );
        else 
            NMat(iFile,:) = 0;
        end
            
 end
        
  
  dNVec = ( dNVec - dNVec(1) ) ./ dNVec(1);

end