close all
clear all

c_CGS = 2.997924d+10;
h_MeV = 4.135667d-21;

% eGrid = CreateEnergyGrid( 0.0, 300.0, 35, 0, 1.0, 5 );
[ eC, dV, ~, Phi0_Out_Old, ~ ] = InitializeNES( '001', 40 );

MeV2K   = 11604525006.1657;

hc3 = ( h_MeV * c_CGS )^3;

EOS_Table = ReadTable_EOS( 'wl-EOS-SFHo-15-25-50-noBCK.h5' );

NES_Table = ReadTable_NES( 'wl-Op-SFHo-15-25-50-E40-B85-NES.h5' );

iHI0  = 1;
iHII0 = 2;

ca = 0.50;
cv = 0.96;

C_I  = ( cv + ca )^2;
C_II = ( cv - ca )^2;

NES_Table.Phi0_Out...
  = C_I .* squeeze( NES_Table.Kernels(:,:,iHI0,:,:) )...
      + C_II .* squeeze( NES_Table.Kernels(:,:,iHII0,:,:) );

T_MeV = 21.0;
D = 1.1d14; T_K = T_MeV * MeV2K; Y = 0.25;

Mu_e = Interpolate_EOS( D, T_K, Y, EOS_Table.Rho, EOS_Table.T, EOS_Table.Ye, EOS_Table.Mu_e, 0.0 );
Eta = Mu_e / T_MeV;

tic
Phi0_Out = Interpolate_NES( eC, eC, T_K, Eta, NES_Table.Energy, NES_Table.Energy, NES_Table.Temperature, NES_Table.Eta, [1,1,1,1], NES_Table.Phi0_Out, 0.0 );
Phi0_Out = c_CGS.*Phi0_Out';% Transpose to compare with original
toc

for i = 1 : size( eC, 1 )
  Integral(i)     = sum( Phi0_Out(i,:)     .* dV(:)' );
  Integral_Old(i) = sum( Phi0_Out_Old(i,:) .* dV(:)' );
end

figure( 1 )
imagesc( log10( eC ), log10( eC ), log10( Phi0_Out ) )

figure( 2 )
imagesc( log10( eC ), log10( eC ), log10( Phi0_Out_Old ) )

figure( 3 )
loglog( eC, Phi0_Out ); hold on
loglog( eC, Phi0_Out_Old, '--' )

figure( 4 )
loglog( eC, Integral ); hold on
loglog( eC, Integral_Old, '--' )