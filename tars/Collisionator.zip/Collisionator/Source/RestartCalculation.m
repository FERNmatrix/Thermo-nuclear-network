function [ N_Restart ] = RestartCalculation(FileDir, FileName, RestartFileNumber)


   
         N_Restart = zeros(40, 1); 
         Data = load( [ FileDir '/' FileName '_' num2str( RestartFileNumber, '%08d' ) ] );
         
         for i = 1:40
         
             N_Restart(i,:) = Data.N(i,:); 
         
         end

end