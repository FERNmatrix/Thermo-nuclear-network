function [ FileNumber ]...
  = Write_Plotfile( t, dt, N, eC, dV, kVec, cMat, cycle, true_cycle, Branch, dt_FE, dt_EA, dt_PE, FileDir, BaseFileName, FileNumber )

  FileName = [ FileDir '/' BaseFileName '_' num2str( FileNumber, '%08d' ) ];

  save( FileName, 't', 'dt', 'N', 'eC', 'dV', 'kVec', 'cMat', 'cycle', 'true_cycle', 'Branch', 'dt_FE', 'dt_EA', 'dt_PE' );
  
  FileNumber = FileNumber + 1;

end