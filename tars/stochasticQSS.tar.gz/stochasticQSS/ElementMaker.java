// -----------------------------------------------------------------------------------------------------------
//  Class ElementMaker to initiate the GUI interface for element production
// -----------------------------------------------------------------------------------------------------------

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import gov.sandia.postscript.PSGr1;

public class ElementMaker {

    public static void main (String[] args) {
        ChooseIsotopes ce = new ChooseIsotopes();
    }

}

